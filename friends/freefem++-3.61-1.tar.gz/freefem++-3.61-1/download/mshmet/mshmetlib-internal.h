typedef MSHMET_Point Point;
typedef MSHMET_Tetra Tetra;
typedef MSHMET_Tria Tria;
typedef MSHMET_Mesh Mesh;
typedef MSHMET_Sol Sol;
typedef MSHMET_Deriv Deriv;

typedef MSHMET_pPoint pPoint; 
typedef MSHMET_pTetra pTetra; 
typedef MSHMET_pDeriv pDeriv;
typedef MSHMET_pTria pTria;   
typedef MSHMET_Info Info;     
typedef MSHMET_pMesh pMesh;   
typedef MSHMET_pSol pSol;

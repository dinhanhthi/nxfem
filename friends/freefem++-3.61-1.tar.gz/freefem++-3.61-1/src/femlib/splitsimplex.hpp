
template<class Rd>  void  SplitSimplex(int N,int & nv, Rd *& P, int & nk , int *& K);
// Add J. Morice for function trunc.
void SplitSurfaceSimplex(int N,int &ntri2, int *&tri);

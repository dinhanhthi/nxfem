<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML//EN">
<html> <head>
<title></title>
<meta http-equiv="Content-type" content="text/html; charset=utf-8">
<link rel="stylesheet" href="ffstyle.css" type="text/css">
</head>
<?php
//  comment in phpp ..
include 'phpfiles.php';
?>
<body bgcolor="#FFFFFF" text="#000000" link="#333333" vlink="#330066" alink="#330066>
<div class="menu">
	<div class="title"><img src="images/chesapeake-2.jpg" width="220"></div>
	<div class="subtitle"><a href="mailto:Free Fem++ <freefempp@ljll.math.umpc.fr>"> mail to FreeFem++ list</a>
    </div>

	<p>
	<div class="menuTitle">Sections</div>
	<div class="menuItem"><a href="main.php"  target="main">Home</a></div>	
	<div class="menuItem"><a href="http://www.um.es/freefem/ff++/pmwiki.php" target="_top">Wiki</a></div>
	<div class="menuItem"><a href="https://ljll.math.upmc.fr/cgi-bin/mailman/listinfo/freefempp" target="_top">Mailing list </a></div>
	 <div class="menuItem"><a href="https://www.ljll.math.upmc.fr/lehyaric/ffcs/index.htm"  target="_top"> FreeFem++-cs </a></div>
	 <div class="menuItem"><a href="https://www.ljll.math.upmc.fr/lehyaric/ffjs"  target="_top"> FreeFem++ on the web </a></div>
	<div class="menuItem"><a href="examples.html"  target="main">Showcase</a></div>	
	<div class="menuItem"><a href="news.php"  target="main">Web News</a></div>	
	 <div class="menuItem"><a href="https://github.com/FreeFem/FreeFem-sources"  target="_top"> github site </a></div>

	</p>
	
		<p>
	<div class="menuTitle">Documentation</div>
	<div class="menuItem"><a href="http://www.freefem.org/ff++/ftp/freefem++doc.pdf" target="_top"> freefem++doc.pdf  <? sizefile("freefem++doc.pdf") ?></a></div>
	<div class="menuItem"><a href="http://www.freefem.org/ff++/ftp/INNOVATION" target="_top">  Last News (INNOVATION) </a></div>
	<div class="menuItem"><a href="http://www.freefem.org/ff++/ftp/HISTORY" target="_top">HISTORY </a></div>
	<div class="menuItem"><a href="http://www.freefem.org/ff++/ftp/BUGS" target="_top">knows BUGS  </a></div>
	<div class="menuItem"><a href="http://www.freefem.org/ff++/ftp/freefem++Spanish.pdf" target="_top">Una documentation en español</a></div>
		<div class="menuItem"><a href="http://www.freefem.org/ff++/ftp/freefem++doc-chinese.pdf" target="_top"> Chinese documentation  </a></div>

	<div class="menuItem"><a href="http://comfos.org/jp/ffempp/index.html" target="_top">Japanese (Kohji Ohtsuka)</a></div>
	 <div class="menuItem"><a href="http://homepage.ntu.edu.tw/~twhsheu/twsiamff++/freefem.html"  target="_top"> TWSIAM Activity Group </a></div>	
	</p>

	<p>
	<div class="menuTitle">Compilation/Installation</div>
	<div class="menuItem"></div>
	<div class="menuItem"><a href="download.php" target="main"> Download </a> </div>
	<div class="menuItem"></div>
	<div class="menuItem"><a href="windows.php" target="_top">Compilation Windows</a></div>
	<div class="menuItem"><a href="macosx.php" target="_top">Compilation MacOS X</a></div>
	<div class="menuItem"><a href="linux.php" target="_top">Compilation Linux</a></div>

	</p>
	
	

	
	<div class="menuTitle">Oldies</div>
	<div class="menuItem"> <a href="https://www.ljll.math.upmc.fr/hecht/bookIDFHOP/bp.tar.gz" target="_top">To
download all the examples</a> (in tar.gz format) from the book
"Simulation numérique en C++" by Ionut Danaila, Frédéric
Hecht, Olivier Pironneau, DUNOD 2003  </div>
	<div class="menuItem"><a href="http://www.freefem.org/ff++/freefem/fraold.htm" target="_top"> freefem </a> The first freefem version </div>

	<div class="menuItem"><a href="http://www.freefem.org/ff++/freefem/index.html" target="_top"> freefem+ </a> The freefem+ version </div>
	<div class="menuItem"><a href="http://www.freefem.org/ff3d/index.html" target="_top">freeFEM3D</a>: the 3D version based on ficticious domain.</div>

	<div class="menuItem"><a href="http://www.freefem.org/ff2a3" target="_top">ANR FF2A3</a></div>
		<div class="menuItem"><a href="https://www.ljll.math.upmc.fr/hecht/ftp/emc2" target="main">emc2 (CAD 2d) </a></div>

	
	</p>
</div>

<address> frederic.hecht@upmc.fr</address>
<!-- hhmts start --> Last modified: Mar 2 juin 2014 11:42:56 CEST  <!-- hhmts end -->
</body> </html>

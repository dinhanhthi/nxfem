<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta http-equiv="Content-Style-Type" content="text/css">
  <title></title>
  <meta name="Generator" content="Cocoa HTML Writer">
  <meta name="CocoaVersion" content="1404.47">
  <style type="text/css">
    p.p1 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 16.0px; font: 14.0px Helvetica; color: #000000; -webkit-text-stroke: #000000}
    p.p2 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 22.0px; font: 19.0px Helvetica; color: #000000; -webkit-text-stroke: #000000}
    p.p3 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 22.0px; font: 19.0px Helvetica; color: #000000; -webkit-text-stroke: #000000; min-height: 23.0px}
    p.p4 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 22.0px; font: 15.0px Helvetica; color: #000000; -webkit-text-stroke: #000000}
    p.p5 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 22.0px; font: 14.0px Helvetica; color: #000000; -webkit-text-stroke: #000000}
    p.p6 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 17.0px; font: 15.0px Helvetica; color: #000000; -webkit-text-stroke: #000000}
    p.p7 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 17.0px; font: 15.0px Helvetica; color: #ff2a1a; -webkit-text-stroke: #ff2a1a}
    p.p8 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 17.0px; font: 15.0px Helvetica; color: #0000ee; -webkit-text-stroke: #0000ee}
    p.p9 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 14.0px; font: 12.0px Helvetica; color: #000000; -webkit-text-stroke: #000000}
    p.p10 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 22.0px; font: 15.0px 'Helvetica Neue'; color: #232323; -webkit-text-stroke: #232323}
    p.p18 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 22.0px; font: 16.0px Courier; color: #008f00; -webkit-text-stroke: #008e54}
    p.p19 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 18.0px; font: 16.0px Arial; color: #000000; -webkit-text-stroke: #000000}
    p.p20 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 18.0px; font: 16.0px Courier; color: #008f00; -webkit-text-stroke: #000000}
    p.p21 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 18.0px; font: 16.0px Courier; color: #008f00; -webkit-text-stroke: #008e54}
    p.p22 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 17.0px; font: 15.0px Helvetica; color: #008f00; -webkit-text-stroke: #000000}
    p.p23 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 17.0px; font: 15.0px Courier; color: #008f00; -webkit-text-stroke: #008e54}
    p.p24 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 17.0px; font: 15.0px Courier; color: #008e54; -webkit-text-stroke: #008e54}
    p.p25 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 15.0px; font: 13.0px Consolas; color: #008f00; -webkit-text-stroke: #008f00}
    p.p26 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 22.0px; font: 18.0px Helvetica; color: #000000; -webkit-text-stroke: #000000}
    p.p27 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 17.0px; font: 15.0px Courier; color: #008e53; -webkit-text-stroke: #008e53}
    p.p28 {margin: 0.0px 0.0px 12.0px 0.0px; line-height: 14.0px; font: 12.0px Times; color: #000000; -webkit-text-stroke: #000000}
    p.p29 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 17.0px; font: 15.0px Helvetica; color: #000000; -webkit-text-stroke: #000000; min-height: 18.0px}
    p.p30 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 14.0px; font: 12.0px Times; color: #000000; -webkit-text-stroke: #000000}
    p.p31 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 18.0px; font: 16.0px Courier; color: #008e53; -webkit-text-stroke: #008e53}
    p.p32 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 17.0px; font: 15.0px Courier; color: #000000; -webkit-text-stroke: #000000}
    p.p33 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 17.0px; font: 15.0px Helvetica; color: #ff0000; -webkit-text-stroke: #ff0000}
    p.p34 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 17.0px; font: 15.0px Helvetica; color: #3e00ff; -webkit-text-stroke: #3e00ff}
    p.p35 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 17.0px; font: 15.0px Helvetica; color: #3e1bfe; -webkit-text-stroke: #3e1bfe}
    p.p36 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 17.0px; font: 15.0px Helvetica; color: #3e02ff; -webkit-text-stroke: #3e02ff}
    p.p37 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 17.0px; font: 15.0px Helvetica; color: #a20092; -webkit-text-stroke: #a20092}
    p.p38 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 17.0px; font: 15.0px Helvetica; color: #1c42d9; -webkit-text-stroke: #1c42d9}
    p.p39 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 17.0px; font: 15.0px Helvetica; color: #6c007d; -webkit-text-stroke: #6c007d}
    li.li11 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 17.0px; font: 15.0px 'Helvetica Neue'; color: #232323; -webkit-text-stroke: #232323}
    li.li12 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 15.0px; font: 13.0px Consolas; color: #008f00; -webkit-text-stroke: #232323}
    li.li13 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 17.0px; font: 13.0px Consolas; color: #008f00; -webkit-text-stroke: #232323}
    li.li14 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 17.0px; font: 15.0px 'Helvetica Neue'; color: #232323}
    li.li15 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 17.0px; font: 15.0px Helvetica; color: #000000}
    li.li16 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 17.0px; font: 15.0px Helvetica; color: #942192}
    li.li17 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 17.0px; font: 19.0px Helvetica; color: #000000; -webkit-text-stroke: #000000}
    span.s1 {font-kerning: none}
    span.s2 {font: 19.0px Helvetica; font-kerning: none}
    span.s3 {text-decoration: underline ; font-kerning: none; color: #0000ee; -webkit-text-stroke: 0px #0000ee}
    span.s4 {font-kerning: none; color: #000000; -webkit-text-stroke: 0px #000000}
    span.s5 {font-kerning: none; color: #008f00; -webkit-text-stroke: 0px #008e53}
    span.s6 {font: 19.0px Helvetica; font-kerning: none; color: #000000; -webkit-text-stroke: 0px #000000}
    span.s7 {font-kerning: none; -webkit-text-stroke: 0px #000000}
    span.s8 {font: 15.0px 'Helvetica Neue'; text-decoration: underline ; font-kerning: none; color: #0b65a5; -webkit-text-stroke: 0px #0077cc}
    span.s9 {-webkit-text-stroke: 0px #000000}
    span.s10 {font: 13.0px Consolas; font-kerning: none; background-color: #eeeeee}
    span.s11 {color: #232323; background-color: #eeeeee; -webkit-text-stroke: 0px #000000}
    span.s12 {font-kerning: none; color: #232323; background-color: #eeeeee; -webkit-text-stroke: 0px #000000}
    span.s13 {font-kerning: none; background-color: #eeeeee}
    span.s14 {font: 15.0px 'Helvetica Neue'; font-kerning: none}
    span.s15 {font: 15.0px 'Helvetica Neue'; color: #232323; -webkit-text-stroke: 0px #000000}
    span.s16 {font: 15.0px 'Helvetica Neue'; font-kerning: none; color: #232323}
    span.s17 {font: 13.0px Consolas; font-kerning: none; color: #008f00; background-color: #eeeeee}
    span.s18 {font: 19.0px Helvetica}
    span.s19 {color: #942192}
    span.s20 {color: #000000}
    span.s21 {font: 16.0px Arial; font-kerning: none; color: #000000}
    span.s22 {font: 16.0px Arial; font-kerning: none}
    span.s23 {font-kerning: none; color: #008e54}
    span.s24 {font-kerning: none; color: #ff2a1a; -webkit-text-stroke: 0px #ff2a1a}
    span.s25 {font-kerning: none; color: #008e53; -webkit-text-stroke: 0px #008e53}
    span.s26 {font: 12.0px Times; text-decoration: underline ; font-kerning: none; color: #0000ee; -webkit-text-stroke: 0px #0000ee}
    span.s27 {font-kerning: none; color: #3e02ff; -webkit-text-stroke: 0px #3e02ff}
    span.s28 {text-decoration: underline ; font-kerning: none}
    span.s29 {font: 15.0px Helvetica; font-kerning: none; color: #000000; -webkit-text-stroke: 0px #000000}
    span.Apple-tab-span {white-space:pre}
    ol.ol1 {list-style-type: decimal}
  </style>
</head>
<body>
<?php
//  comment in phpp ..
include 'phpfiles.php';
?>
<p class="p2">To install the precompile windows package just<span class="Apple-converted-space"> </span></p>
<p class="p2">download the last version from </p>
<p class="p2">Take the file form and download </p> 

    <? pfile($wfile,"Windows 32bits") ?>
    <? pfile($w64file,"Windows 64bits") ?>
 
<p class="p1"><span class="s1">And execute<span class="Apple-converted-space">  </span>and<span class="Apple-converted-space">  </span>follow the instruction.</span></p>
<p class="p1"><span class="s19">Warning: if you launch freefem++ without filename script by double clip, your get a error due (it is bug of usage <tt>GetOpenFileName</tt> in win64 ). </span></p>
<p class="p1"><span class="s1"> To launch mpi version  :</span> </p> 
<p class="p1"> first  install MSMPI  for parallel version under window64: 
	Download : <a href="https://www.microsoft.com/en-us/download/details.aspx?id=49926">MS MPI V7</a>, and install both msmpisdk.msi and MSMpiSetup.exe</p>
<p class="p1"><span class="s1">  In shell terminal (cmd, powershell, bash, ... ) do in correct directory:</span> </p> 

<span class="s15"><span class="s13">mpiexec.exe -np 4  FreeFem++-mpi DDM-Schwarz-Lame-2d.edp</span></span><br>

	
<p class="p1"><span class="s1"><br>
</span></p>
<p class="p2"><span class="s1"><br>
</span></p>
<p class="p3"><span class="s1"><span class="Apple-converted-space"> </span></span></p>
<p class="p4"><span class="s2">-- </span><span class="s1">How to compile under MSYS2<span class="Apple-converted-space">  </span>FreeFem++ for Microsoft Windows 64 (for </span><span class="s3">version Windows 32 </span><span class="s1">)<span class="Apple-converted-space">   </span></span></p>
<p class="p5"><span class="s2"><span class="Apple-converted-space">    </span></span><span class="s1">F. Hecht<span class="Apple-converted-space">  </span>(Paris, april<span class="Apple-converted-space">  </span>the 20th, 2016)<span class="Apple-converted-space"> </span></span></p>
<p class="p6"><span class="s1">---------------------------------------------</span></p>
<p class="p7"><span class="s1">WARNING<span class="Apple-converted-space">  </span>NOW the window 64 version<span class="Apple-converted-space">  </span>is compiled under MSYS2 </span><span class="s4">for version<span class="Apple-converted-space">  </span>before version 3.47 , see<span class="Apple-converted-space"> </span></span></p>
<p class="p6"><span class="s1"><br>
</span></p>
<p class="p6"><span class="s1">typo remark: all line in </span><span class="s5">green</span><span class="s1"><span class="Apple-converted-space">  </span>are shell command under mingw32 shell</span></p>
<p class="p6"><span class="s1"><br>
1. Download and install msys2 version x86_64 <span class="Apple-converted-space"> </span></span></p>
<p class="p8"><span class="s4">form <a href="https://msys2.github.io/"><span class="s3">https://msys2.github.io</span></a></span></p>
<p class="p9"><span class="s1">Answer question in following  windows : </span></p>
<p class="p10"><span class="s6"><br>
</span><span class="s7"><span class="Apple-converted-space">  </span>1.<span class="Apple-tab-span">	</span></span><span class="s1">Download MSYS2 from <a href="http://sourceforge.net/p/msys2/wiki/MSYS2%20installation/"><span class="s8">this page</span></a> (choose 32 or 64-bit according to what version of Windows you are going to use it on, not what kind of executables you want to build, both versions can build both 32 and 64-bit binaries).</span></p>
<ol class="ol1">
  <li class="li11"><span class="s9"></span><span class="s1">After the install completes, click on the newly created "MSYS2 Shell" option under either </span><span class="s10">MSYS2 64-bit</span><span class="s1"> or </span><span class="s10">MSYS2 32-bit</span><span class="s1"> in the Start menu. Update MSYS2 according to the wiki (although I just do a<span class="Apple-converted-space"> </span></span></li>
  <li class="li12"><span class="s11"></span><span class="s12"><span class="Apple-converted-space">    </span></span><span class="s13">pacman -Syu</span><span class="s14">,</span></li>
  <li class="li11"><span class="s9"></span><span class="s1">ignore all errors and close the window and open a new one, this is not recommended and you should do what the wiki page says).</span></li>
  <li class="li13"><span class="s15"></span><span class="s16">Install<span class="Apple-converted-space">  </span>all this tools : <br>
</span><span class="s13">pacman -S autoconf</span><span class="s16"><br>
</span><span class="s13">pacman -S automake-wrapper</span><span class="s16"><br>
</span><span class="s13">pacman -S bash</span><span class="s16"><br>
</span><span class="s13">pacman -S bash-completion</span><span class="s16"><br>
</span><span class="s13">pacman -S bison</span><span class="s16"><br>
</span><span class="s13">pacman -S bsdcpio</span><span class="s16"><br>
</span><span class="s13">pacman -S bsdtar</span><span class="s16"><br>
</span><span class="s13">pacman -S bzip2</span><span class="s16"><br>
</span><span class="s13">pacman -S coreutils</span><span class="s16"><br>
</span><span class="s13">pacman -S curl</span><span class="s16"><br>
</span><span class="s13">pacman -S dash</span><span class="s16"><br>
</span><span class="s13">pacman -S file</span><span class="s16"><br>
</span><span class="s13">pacman -S filesystem</span><span class="s16"><br>
</span><span class="s13">pacman -S findutils</span><span class="s16"><br>
</span><span class="s13">pacman -S flex</span><span class="s16"><br>
</span><span class="s13">pacman -S gawk</span><span class="s16"><br>
</span><span class="s13">pacman -S gcc-libs</span><span class="s16"><br>
</span><span class="s13">pacman -S grep</span><span class="s16"><br>
</span><span class="s13">pacman -S gzip</span><span class="s16"><br>
</span><span class="s13">pacman -S inetutils</span><span class="s16"><br>
</span><span class="s13">pacman -S info</span><span class="s16"><br>
</span><span class="s13">pacman -S less</span><span class="s16"><br>
</span><span class="s13">pacman -S lndir</span><span class="s16"><br>
</span><span class="s13">pacman -S make</span><span class="s16"><br>
</span><span class="s13">pacman -S man-db</span><span class="s16"><br>
</span><span class="s13">pacman -S git</span><span class="s16"><br>
</span><span class="s13">pacman -S mingw-w64-x86_64-freeglut</span><span class="s16"><br>
</span><span class="s13">pacman -S mingw-w64-x86_64-gcc</span><span class="s16"><br>
</span><span class="s13">pacman -S mingw-w64-x86_64-gcc-fortran</span><span class="s16"><br>
</span><span class="s13">pacman -S mingw-w64-x86_64-gsl</span><span class="s16"><br>
</span><span class="s13">pacman -S mingw-w64-x86_64-hdf5</span><span class="s16"><br>
</span><span class="s13">pacman -S mingw-w64-x86_64-openblas</span><span class="s16"><br>
</span><span class="s13">pacman -S mintty</span><span class="s16"><br>
</span><span class="s13">pacman -S msys2-keyring</span><span class="s16"><br>
</span><span class="s13">pacman -S msys2-launcher-git</span><span class="s16"><br>
</span><span class="s13">pacman -S msys2-runtime</span><span class="s16"><br>
</span><span class="s13">pacman -S ncurses</span><span class="s16"><br>
</span><span class="s13">pacman -S pacman</span><span class="s16"><br>
</span><span class="s13">pacman -S pacman-mirrors</span><span class="s16"><br>
</span><span class="s13">pacman -S pactoys-git</span><span class="s16"><br>
</span><span class="s13">pacman -S patch</span><span class="s16"><br>
</span><span class="s13">pacman -S pax-git</span><span class="s16"><br>
</span><span class="s13">pacman -S perl</span><span class="s16"><br>
</span><span class="s13">pacman -S pkg-config</span><span class="s16"><br>
</span><span class="s13">pacman -S pkgfile</span><span class="s16"><br>
</span><span class="s13">pacman -S rebase</span><span class="s16"><br>
</span><span class="s13">pacman -S sed</span><span class="s16"><br>
</span><span class="s13">pacman -S tar</span><span class="s16"><br>
</span><span class="s13">pacman -S tftp-hpa</span><span class="s16"><br>
</span><span class="s13">pacman -S time</span><span class="s16"><br>
</span><span class="s13">pacman -S tzcode</span><span class="s16"><br>
</span><span class="s13">pacman -S unzip</span><span class="s16"><br>
</span><span class="s13">pacman -S util-linux</span><span class="s16"><br>
</span><span class="s13">pacman -S which</span><span class="s16"><br>
<br>
<br>
</span></li>
  <li class="li11"><span class="s9"></span><span class="s1">install any libraries/tools you may need. You can search the repositories by doing<br>
</span><span class="s17">pacman -Ss package_name_of_something_i_want_to_install</span></li>
  <li class="li14"></li>
  <li class="li11"><span class="s9"></span><span class="s1">Open a MinGW-w64 shell:<br>
a) To build 32-bit things, open the "MinGW-w64 32-bit Shell"<br>
b) To build 64-bit things, open the "MinGW-w64 64-bit Shell"</span></li>
  <li class="li15"><span class="s18"></span>install MSMPI<span class="Apple-converted-space">  </span>for parallel version under window64</li>
  <li class="li15"><span class="Apple-converted-space">    <span class="Apple-tab-span">	</span></span>download <a href="https://www.microsoft.com/en-us/download/details.aspx?id=49926">MS MPI V7</a>, and install both msmpisdk.msi and MSMpiSetup.exe</li>
  <li class="li15"><span class="Apple-converted-space">         </span>open <span class="s19">c:\msys64\mingw64.ini</span> in an editor and remove</span><span class="Apple-converted-space"> </span></li>
  <li class="li15"><span class="s20"><span class="Apple-converted-space">           </span>“</span>rem<span class="s20">” or "<span class="s19">#</span>" before “</span>set MSYS2_PATH_TYPE=inherit<span class="s20">”<span class="Apple-converted-space"> </span></span></li>
  <li class="li15"><span class="Apple-converted-space">           </span>(this enables passing Windows environment variables to MSYS2-MINGW64)</li>
 
</span></li>
</ol>
<p class="p2"><span class="s1">Now you can do classical install<span class="Apple-converted-space"> </span></span></p>
<p class="p18"><span class="s6"><span class="Apple-converted-space">      </span></span><span class="s1">git clone<span class="Apple-converted-space">  </span>https://github.com/FreeFem/FreeFem-sources ff++</span></p>
<p class="p19"><span class="s1">Now you can do develop  install</span></p>
<p class="p18"><span class="s6"><span class="Apple-converted-space">      </span></span><span class="s1">git clone -b develop <span class="Apple-converted-space">  </span>https://github.com/FreeFem/FreeFem-sources ff++</span></p>
<p class="p19"><span class="s1">Now update version </span></p>
<p class="p20"><span class="s21"><span class="Apple-converted-space">      </span></span><span class="s22"> </span><span class="s1">cd ff++</span></p>
<p class="p21"><span class="s1"><span class="Apple-converted-space">   </span>git  pull </span></p>
<p class="p22"><span class="s1"><br>
</span></p>
<p class="p6"><span class="s1">To restore, all files build by autoreconf -i command (automake):</span></p>
<p class="p23"><span class="s23"><span class="Apple-converted-space">   </span></span><span class="s1">tar zxvf AutoGeneratedFile.tar.gz<span class="Apple-converted-space"> </span></span></p>
<p class="p6"><span class="s1">Finally, the configure argument are and the compile<span class="Apple-converted-space"> </span></span></p>
<p class="p6"><span class="s1"><span class="Apple-converted-space">  </span>(remark :<span class="Apple-converted-space">  </span>sorry pastix and hips does not compile under window to day, so I<span class="Apple-converted-space">  </span>disable its)</span></p>
<p class="p23"><span class="s1"><span class="Apple-converted-space">    </span>./configure '--enable-download' '--disable-pastix' '--disable-hips'</span></p>
<p class="p23"><span class="s1"><span class="Apple-converted-space">    </span>make</span></p>
<p class="p23"><span class="s1"><span class="Apple-tab-span">	</span>make check</span></p>
<p class="p24"><span class="s1"><br>
</span></p>
<p class="p24"><span class="s1"><br>
</span></p>
<p class="p6"><span class="s1">Remark to see all dll use by file.dll file <br>
</span></p>
<p class="p25"><span class="s13">objdump.exe -p file.dll | grep -i dll</span></p>
<p class="p24"><span class="s1"><br>
</span></p>
<p class="p2"><span class="s1"><br>
</span></p>
<p class="p26"><span class="s2">-- </span><span class="s1"><b>How to compile FreeFem++ on Microsoft Windows (win32) under Mingw32<span class="Apple-converted-space"> </span></b></span></p>
<p class="p5"><span class="s2"><span class="Apple-converted-space">    </span></span><span class="s1">F. Hecht<span class="Apple-converted-space">  </span>(Paris, Sept. the 4th, 2013)<span class="Apple-converted-space"> </span></span></p>
<p class="p6"><span class="s1">---------------------------------------------</span></p>
<p class="p6"><span class="s24"><span class="Apple-converted-space"> </span>the window version<span class="Apple-converted-space">  </span>is compiled under MINGW </span><span class="s1">for version<span class="Apple-converted-space">  </span>before version 3.20 , oct 7h 2012 , see the end of the file (obsolete now)</span></p>
<p class="p6"><span class="s1"><br>
</span></p>
<p class="p6"><span class="s1">typo remark: all line in </span><span class="s25">green</span><span class="s1"><span class="Apple-converted-space">  </span>are shell command under mingw32 shell</span></p>
<p class="p6"><span class="s1"><br>
</span></p>
<p class="p6"><span class="s1">1. Download and install MINGW32<span class="Apple-converted-space"> </span></span></p>
<p class="p8"><span class="s4">form <a href="http://sourceforge.net/projects/mingw/files/Installer/mingw-get-setup.exe/download"><span class="s3">http://sourceforge.net/projects/mingw/files/Installer/mingw-get-setup.exe/download</span></a></span></p>
<p class="p9"><span class="s1">Answer question in following  windows : </span></p>
<p class="p9"><span class="s1">  7) select  components<span class="Apple-converted-space"> </span></span></p>
<p class="p9"><span class="s1">     all basic setup<span class="Apple-converted-space"> </span></span></p>
<p class="p9"><span class="s1">     all package : in mingw32 mingw-devlopper-tool, autoconf , automake, compiler, wget , ...<span class="Apple-converted-space"> </span></span></p>
<p class="p9"><span class="s1">  8)   Installation -&gt; Apply changes  </span></p>
<p class="p6"><span class="s1"><br>
</span></p>
<p class="p6"><span class="s1">2. Under mingw32 shell install wget and unzip</span></p>
<p class="p27"><span class="s1"><span class="Apple-converted-space"> </span>mingw-get install msys-wget</span></p>
<p class="p27"><span class="s1"><span class="Apple-converted-space"> </span>mingw-get.exe install msys-unzip</span></p>
<p class="p6"><span class="s1"><br>
</span></p>
<p class="p6"><span class="s1">3. To install freeglut of win32 for the graphics part</span></p>
<p class="p6"><span class="s1"><br>
</span></p>
<p class="p27"><span class="s1">wget http://files.transmissionzero.co.uk/software/development/GLUT/freeglut-MinGW.zip<span class="Apple-converted-space"> </span></span></p>
<p class="p27"><span class="s1">unzip freeglut-MinGW-2.8.0-1.mp.zip</span></p>
<p class="p27"><span class="s1">cp freeglut/include/GL/* /c/MinGW/include/GL/.</span></p>
<p class="p27"><span class="s1">cp freeglut/lib/lib*.a /c/MinGW/lib/.</span></p>
<p class="p27"><span class="s1">cp freeglut/bin/freeglut.dll /c/MinGW/bin</span></p>
<p class="p6"><span class="s1"><br>
</span></p>
<p class="p6"><span class="s1">4. install a good blas (OpenBlas) http://xianyi.github.com/OpenBLAS/</span></p>
<p class="p8"><span class="s4"><span class="Apple-converted-space">   </span>get from<span class="Apple-converted-space">  </span><a href="http://github.com/xianyi/OpenBLAS/tarball/v0.2.3"><span class="s3">http://github.com/xianyi/OpenBLAS/tarball/v0.2.3</span></a></span></p>
<p class="p28"><span class="s1"><br>
</span></p>
<p class="p28"><span class="s1"><br>
</span></p>
<p class="p27"><span class="s1">wget http://github.com/xianyi/OpenBLAS/tarball/v0.2.3 -O OpenBlas.tgz<span class="Apple-converted-space"> </span></span></p>
<p class="p27"><span class="s1">tar zxvf OpenBlas.tgz<span class="Apple-converted-space"> </span></span></p>
<p class="p27"><span class="s1">cd xianyi-OpenBLAS-*/.<span class="Apple-converted-space"> </span></span></p>
<p class="p27"><span class="s1">make<span class="Apple-converted-space"> </span></span></p>
<p class="p27"><span class="s1">make install PREFIX=$HOME/soft</span></p>
<p class="p27"><span class="s1">mkdir $HOME/soft/bin<span class="Apple-converted-space"> </span></span></p>
<p class="p27"><span class="s1">cp *.dll $HOME/soft/bin<span class="Apple-converted-space"> </span></span></p>
<p class="p28"><span class="s1"><br>
</span></p>
<p class="p28"><span class="s1"><br>
</span></p>
<p class="p6"><span class="s1">5. install MPI for // HPC Pack 2008 R2 Client Pack 4<span class="Apple-converted-space"> </span></span></p>
<p class="p6"><span class="s1">and install MPI for // HPC Pack 2008 R2 Pack 4<span class="Apple-converted-space"> </span></span></p>
<p class="p29"><span class="s1"><span class="Apple-converted-space">  </span></span></p>
<p class="p6"><span class="s1">6. install inno setup to build installer :<span class="Apple-converted-space"> </span></span></p>
<p class="p8"><span class="s4"><span class="Apple-converted-space">  </span><a href="http://www.xs4all.nl/~mlaan2/ispack/isetup-5.4.0.exe"><span class="s3">http://www.xs4all.nl/~mlaan2/ispack/isetup-5.4.0.exe</span></a></span></p>
<p class="p6"><span class="s1"><br>
</span></p>
<p class="p6"><span class="s1">7. GSL for gsl interface is take form</span></p>
<p class="p8"><span class="s4"><span class="Apple-converted-space">   </span><a href="http://sourceforge.net/projects/mingw-cross/files/%5BLIB%5D%20GSL/mingw32-gsl-1.14-1/"><span class="s3">http://sourceforge.net/projects/mingw-cross/files/%5BLIB%5D%20GSL/mingw32-gsl-1.14-1/</span></a></span></p>
<p class="p6"><span class="s1"><br>
</span></p>
<p class="p6"><span class="s1">9) To download the latest freefem++ tar.gz file contening source form<span class="Apple-converted-space"> </span></span></p>
<p class="p30"><span class="s1">or you can get the latest source from an anonymous <a href="https://git-scm.com"><span class="s26">git SCM </span></a>copy with the following unix shell commands :</span></p>
<p class="p31"><span class="s1">git clone<span class="Apple-converted-space">  </span>https://github.com/FreeFem/FreeFem-sources ff++</span></p>
<p class="p19"><span class="s1">to update do to the last version:</span></p>
<p class="p31"><span class="s1">git checkout master</span></p>
<p class="p6"><span class="s1"><br>
</span></p>
<p class="p6"><span class="s1">To restore, all files build by autoreconf -i command (automake):</span></p>
<p class="p27"><span class="s1">tar zxvf AutoGeneratedFile.tar.gz<span class="Apple-converted-space"> </span></span></p>
<p class="p6"><span class="s1">Finaly, the configure argument are:</span></p>
<p class="p6"><span class="s1">10)<span class="Apple-converted-space">  </span>Finaly, the configure argument are :</span></p>
<p class="p27"><span class="s1">./configure ’--enable-download’ ’FC=mingw32-gfortran’ ’F77=mingw32-gfortran’ ’CC=mingw32-gcc’ ’CXX=mingw32-g++’ ’-with-blas=$HOME/soft/bin/libopenblas.dll’ ’CXXFLAGS=-I$HOME/soft/include’ ’--enable-generic’ ’--with-wget=wget’ ’MPIRUN=/c/Program Files/Microsoft HPC Pack 2008 R2/Bin/mpiexec.exe</span></p>
<p class="p32"><span class="s1"><br>
</span></p>
<p class="p6"><span class="s1">-----------------------------------------------------------------------------------------------------------------------------</span></p>
<p class="p6"><span class="s1">Ok until version 3.19-1 (but now this soft is to old to get form the web).<span class="Apple-converted-space"> </span></span></p>
<p class="p6"><span class="s1">FIle version 30/11/2011 F. Hecht.<span class="Apple-converted-space"> </span></span></p>
<p class="p6"><span class="s1"><br>
</span></p>
<p class="p33"><span class="s1">WARNING<span class="Apple-converted-space">  </span>NOW the window version<span class="Apple-converted-space">  </span>is compiled under MINGW<span class="Apple-converted-space">  </span>(from version 3.11<span class="Apple-converted-space">  </span>14/01/2011 FH)</span></p>
<p class="p6"><span class="s1">So the old dll are incompatible with the new version.<span class="Apple-converted-space"> </span></span></p>
<p class="p6"><span class="s1">It is the fortran compiler under cygwin which is too old<span class="Apple-converted-space">  </span>(not f90 under cygwin).<span class="Apple-converted-space"> </span></span></p>
<p class="p6"><span class="s1">----------------------------------------------------------</span></p>
<p class="p6"><span class="s1">The<span class="Apple-converted-space">  </span>tools to<span class="Apple-converted-space">  </span>be installed are:</span></p>
<p class="p6"><span class="s1"><br>
</span></p>
<p class="p6"><span class="s1"><b>1) Download and install MINGW32<span class="Apple-converted-space"> </span></b></span></p>
<p class="p6"><span class="s1"><br>
</span></p>
<p class="p34"><span class="s1">http://sunet.dl.sourceforge.net/project/mingw/Automated%20MinGW%20Installer/mingw-get-inst/mingw-get-inst-20101030/mingw-get-inst-20101030.exe</span></p>
<p class="p34"><span class="s1"><br>
</span></p>
<p class="p9"><span class="s1">launch:<span class="Apple-converted-space"> </span></span></p>
<p class="p9"><span class="s1"><span class="Apple-converted-space">   </span> mingw-get-inst-20101030.exe</span></p>
<p class="p9"><span class="s1"><br>
</span></p>
<p class="p9"><span class="s1">Answer question in following  windows : </span></p>
<p class="p9"><span class="s1">   1) do next </span></p>
<p class="p9"><span class="s1">   2) do next </span></p>
<p class="p9"><span class="s1">   3) use preload case </span></p>
<p class="p9"><span class="s1">   4)  accept </span></p>
<p class="p9"><span class="s1">   5 ) select   location of mingw on disk. </span></p>
<p class="p9"><span class="s1">   6) mingw menu name </span></p>
<p class="p9"><span class="s1">  7) select  components</span></p>
<p class="p9"><span class="s1">     all except  ada </span></p>
<p class="p9"><span class="s1">  8)   do install </span></p>
<p class="p34"><span class="s1"><br>
</span></p>
<p class="p6"><span class="s1"><br>
</span></p>
<p class="p6"><span class="s1"><b>2) Download and install wget</b> for --enable-download in configure</span></p>
<p class="p34"><span class="s1">http://puzzle.dl.sourceforge.net/project/mingw/mingwPORT/Current%20Releases/wget-1.9.1-mingwPORT.tar.bz2</span></p>
<p class="p6"><span class="s1">under mingw32 shell<span class="Apple-converted-space"> </span></span></p>
<p class="p6"><span class="s1">do:<span class="Apple-converted-space"> </span></span></p>
<p class="p6"><span class="s1">cd /c/users/loginname/download/</span></p>
<p class="p35"><span class="s4">tar jxvf </span><span class="s1">wget-1.9.1-mingwPORT.tar.bz2</span></p>
<p class="p35"><span class="s1">cp<span class="Apple-converted-space"> </span></span></p>
<p class="p6"><span class="s1">extract and move wget.exe in /usr/bin<span class="Apple-converted-space"> </span></span></p>
<p class="p6"><span class="s1"><br>
</span></p>
<p class="p6"><span class="s1"><b>3) The glut of win32 from</b></span></p>
<p class="p6"><span class="s1"><br>
</span></p>
<p class="p34"><span class="s27">wget<span class="Apple-converted-space">  </span></span><span class="s1">http://web.cs.wpi.edu/~gogo/courses/mingw/winglut.zip</span></p>
<p class="p34"><span class="s1">or<span class="Apple-converted-space"> </span></span></p>
<p class="p36"><span class="s1">wget http://files.transmissionzero.co.uk/software/development/GLUT/freeglut-MinGW.zip</span></p>
<p class="p6"><span class="s1"><br>
</span></p>
<p class="p6"><span class="s1">The location of include file must be<span class="Apple-converted-space"> </span></span></p>
<p class="p6"><span class="s1"><br>
</span></p>
<p class="p37"><span class="s1">c:\mingw\include\GL\glut.h</span></p>
<p class="p37"><span class="s1">c:\mingw\include\GL\gl.h</span></p>
<p class="p37"><span class="s1">c:\mingw\include|GL/glu.h</span></p>
<p class="p6"><span class="s1"><br>
</span></p>
<p class="p6"><span class="s1">add the glut32.dll or freeglut.dll in you directory in the 2 directories:</span></p>
<p class="p6"><span class="s1"><br>
</span></p>
<p class="p6"><span class="s1">$ find /c/MinGW -name glut</span></p>
<p class="p37"><span class="s1">/c/MinGW/bin/glut32.dll</span></p>
<p class="p37"><span class="s1">/c/MinGW/lib/glut32.dll</span></p>
<p class="p29"><span class="s1"><span class="Apple-converted-space"> </span></span></p>
<p class="p6"><span class="s1"><b>4) the good blas now is:</b><span class="Apple-converted-space"> </span></span></p>
<p class="p6"><span class="s1"><br>
</span></p>
<p class="p34"><span class="s1">http://www.tacc.utexas.edu/tacc-projects/gotoblas2/downloads/</span></p>
<p class="p6"><span class="s1"><br>
</span></p>
<p class="p6"><span class="s1">Try to compile<span class="Apple-converted-space"> </span></span></p>
<p class="p6"><span class="s1"><br>
</span></p>
<p class="p6"><span class="s1"><b>5) install MPI for // versio</b>n<span class="Apple-converted-space"> </span></span></p>
<p class="p6"><span class="s1">HPC Pack 2008 SDK</span></p>
<p class="p38"><span class="s1">http://www.microsoft.com/download/en/details.aspx?id=10505</span></p>
<p class="p6"><span class="s1">HPC Pack 2008 R2 Service Pack 2</span></p>
<p class="p38"><span class="s1">http://www.microsoft.com/download/en/details.aspx?id=26646</span></p>
<p class="p34"><span class="s1"><br>
</span></p>
<p class="p6"><span class="s1"><br>
</span></p>
<p class="p6"><span class="s1"><b>6) install<span class="Apple-converted-space">  </span>inno setup to build installer:<span class="Apple-converted-space"> </span></b></span></p>
<p class="p34"><span class="s1">http://www.xs4all.nl/~mlaan2/ispack/isetup-5.4.0.exe</span></p>
<p class="p6"><span class="s1"><br>
</span></p>
<p class="p6"><span class="s1"><b>7) GSL for gsl interface<span class="Apple-converted-space">  </span>from</b><span class="Apple-converted-space"> </span></span></p>
<p class="p8"><span class="s28"><a href="http://sourceforge.net/projects/mingw-cross/files/%5BLIB%5D%20GSL/mingw32-gsl-1.14-1/mingw32-gsl-1.14-1.zip/download">Download Now! mingw32-gsl-1.14-1.zip (3.5 MB)</a></span></p>
<p class="p6"><span class="s1"><br>
</span></p>
<p class="p6"><span class="s1">8) download git for windows from:</span></p>
<p class="p8"><span class="s28"><a href="https://git-scm.com">https://git-scm.com</a></span></p>
<p class="p6"><span class="s1"><br>
</span></p>
<p class="p6"><span class="s1">9) To download the latest freefem++ tar.gz file contening source form<span class="Apple-converted-space"> </span></span></p>
<p class="p30"><span class="s1">or you can get the latest source from an anonymous <a href="https://git-scm.com"><span class="s26">git SCM </span></a>copy with the following unix shell commands :</span></p>
<p class="p31"><span class="s1">git  clone<span class="Apple-converted-space">  </span>https://github.com/FreeFem/FreeFem-sources ff++</span></p>
<p class="p19"><span class="s1">to update do to the last version:</span></p>
<p class="p31"><span class="s1">git  checkout</span></p>
<p class="p6"><span class="s1"><br>
</span></p>
<p class="p6"><span class="s1"><b>To restore, all file build by autoreconf -i command (automake c):</b></span></p>
<p class="p27"><span class="s1">tar zxvf AutoGeneratedFile.tar.gz<span class="Apple-converted-space"> </span></span></p>
<p class="p6"><span class="s1"><b>Finaly, the configure argument are:</b></span></p>
<p class="p27"><span class="s1">cd ff++</span></p>
<p class="p27"><span class="s1">./configure '--enable-download' 'FC=mingw32-gfortran' 'F77=mingw32-gfortran' 'CC=mingw32-gcc' 'CXX=mingw32-g++' '-with-blas=/home/hecht/blas-x86/libgoto2.dll' 'CXXFLAGS=-I/home/hecht/blas-x86' '--enable-generic' '--with-wget=wget' 'MPIRUN=/c/Program Files/Microsoft HPC Pack 2008 R2/Bin/mpiexec.exe'</span></p>
<p class="p39"><span class="s1"><br>
</span></p>
<p class="p39"><span class="s1">if erreor where building DOC do:</span></p>
<p class="p27"><span class="s29">t</span><span class="s1">ouch DOC/freefem++doc.pdf</span></p>
<p class="p6"><span class="s1"><br>
</span></p>
<p class="p6"><span class="s1"><br>
</span></p>
<p class="p6"><span class="s1">Good Luck …<span class="Apple-converted-space"> </span></span></p>
<p class="p6"><span class="s1"><br>
</span></p>
<p class="p6"><span class="s1"><br>
</span></p>
</body>
</html>
